# fantastic-barnacle-devops
Spring 2026 CIS 486. 

trigger action? 
== 

## deployments
Production => http://34.125.138.224
Development =>
Docs => github pages 

